package com.example.ex02;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void pesquisar(View view){

        EditText id = findViewById(R.id.txtNome);
        TextView titulo = findViewById(R.id.txtTitulo);
        TextView complemento = findViewById(R.id.txtComplemento);
        TextView status = findViewById(R.id.txtStatus);

        String url = "https://jsonplaceholder.typicode.com/todos/";

        url += id.getText().toString();

        new DataGetter(titulo, complemento, status).execute(url);

    }
}